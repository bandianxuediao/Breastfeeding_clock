#ifndef __HanShu_H
#define __HanShu_H

#include "stm32f10x.h"

uint32_t  A1A2A3A4_SPELLED_32bitsWord(uint8_t a1,uint8_t a2,uint8_t a3,uint8_t a4);
#endif
