#ifndef _KEYINPROCESS_H_
#define _KEYINPROCESS_H_

extern void KeyInPro(MSG msg);

#endif
