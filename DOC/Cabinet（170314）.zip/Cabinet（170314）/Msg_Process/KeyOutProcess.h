#ifndef _KEYOUTPROCESS_H_
#define _KEYOUTPROCESS_H_

extern void KeyOutPro(MSG msg);

#endif
