#ifndef _KEY0PROCESS_H_
#define _KEY0PROCESS_H_

extern void Key0Pro(MSG msg);

#endif
