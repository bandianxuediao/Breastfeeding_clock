#ifndef _KEY1PROCESS_H_
#define _KEY1PROCESS_H_

extern void Key1Pro(MSG msg);

#endif
