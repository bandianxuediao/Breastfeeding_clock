#ifndef _KEYSYSPROCESS_H_
#define _KEYSYSPROCESS_H_

extern void KeySysPro(MSG msg);

#endif
