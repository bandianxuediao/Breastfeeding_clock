#ifndef _KEY3PROCESS_H_
#define _KEY3PROCESS_H_

extern void Key3Pro(MSG msg);

#endif
