#ifndef _KEY7PROCESS_H_
#define _KEY7PROCESS_H_

extern void Key7Pro(MSG msg);

#endif
