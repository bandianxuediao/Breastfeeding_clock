#ifndef _KEY8PROCESS_H_
#define _KEY8PROCESS_H_

extern void Key8Pro(MSG msg);

#endif
