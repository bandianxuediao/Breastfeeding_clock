#ifndef _KEY4PROCESS_H_
#define _KEY4PROCESS_H_

extern void Key4Pro(MSG msg);

#endif
