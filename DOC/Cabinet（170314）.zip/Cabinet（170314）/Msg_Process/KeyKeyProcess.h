#ifndef _KEYKEYPROCESS_H_
#define _KEYKEYPROCESS_H_

extern void KeyKeyPro(MSG msg);

#endif
