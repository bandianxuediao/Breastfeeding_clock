#ifndef _KEY9PROCESS_H_
#define _KEY9PROCESS_H_

extern void Key9Pro(MSG msg);

#endif
