#ifndef _NULLPROCESS_H_
#define _NULLPROCESS_H_

extern void NullPro(MSG msg);

#endif
