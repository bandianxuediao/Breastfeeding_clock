#ifndef _KEYBACKPROCESS_H_
#define _KEYBACKPROCESS_H_

extern void KeyBackPro(MSG msg);

#endif
