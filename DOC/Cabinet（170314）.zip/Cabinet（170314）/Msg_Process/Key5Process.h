#ifndef _KEY5PROCESS_H_
#define _KEY5PROCESS_H_

extern void Key5Pro(MSG msg);

#endif
