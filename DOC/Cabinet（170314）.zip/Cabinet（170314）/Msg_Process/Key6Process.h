#ifndef _KEY6PROCESS_H_
#define _KEY6PROCESS_H_

extern void Key6Pro(MSG msg);

#endif
