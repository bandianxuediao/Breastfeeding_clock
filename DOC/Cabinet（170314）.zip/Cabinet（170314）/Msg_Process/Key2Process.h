#ifndef _KEY2PROCESS_H_
#define _KEY2PROCESS_H_

extern void Key2Pro(MSG msg);

#endif
