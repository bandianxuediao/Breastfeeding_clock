#ifndef _KEYSUREPROCESS_H_
#define _KEYSUREPROCESS_H_

extern void KeySurePro(MSG msg);

#endif
