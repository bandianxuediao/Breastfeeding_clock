#ifndef __SPEEKER_H
#define __SPEEKER_H
#include "sys.h"

#define One_Line_High 	GPIO_SetBits(GPIOB,GPIO_Pin_14)
#define One_Line_Low 		GPIO_ResetBits(GPIOB,GPIO_Pin_14)
#define Busy_Line 			GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)

extern void One_Line_1(void);
extern void One_Line_0(void);
extern void Speeker_Init(void);
extern void voice_test(u8 temp);
extern void make_voice(u8 temp);
extern void voice_num(u8 temp);
extern void Busy_Line_Int(void);

#endif

