#include "includes.h"



//��ʼ��PB14.��ʹ������ڵ�ʱ��		    
//LED IO��ʼ��
void Speeker_Init(void)
{
 
 GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB,PC�˿�ʱ��  
	
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;				
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOB, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOB.5
 Busy_Line_Int();
	
 One_Line_High; 
 GPIO_SetBits(GPIOB,GPIO_Pin_13);
	
 make_voice(0xE0);//ȷ���豸�����������F0����Ϊ30
 delay_us(1500);
 make_voice(0xFC);//ֹͣ���ȷ��Busy�ߴ��ڸߵ�ƽ
}

void Busy_Line_Int(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure; 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB,PC�˿�ʱ��  
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;				
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU   ; 		 //��������		
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOB, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOB.5
}


 void One_Line_1(void)
{
		One_Line_High; 						
		delay_us(1500);
		One_Line_Low; 						 
		delay_us(500);
}
 void One_Line_0(void)
{
		One_Line_High; 						
		delay_us(500);
		One_Line_Low; 						 
		delay_us(1500);
}

void voice_test(u8 temp)
{
	
	
}

void voice_num(u8 temp)
{
	u8 hundred , ten , bit;
	hundred = temp/100;
	ten = temp%100/10;
	bit = temp%10;
	if(hundred > 0)
	{
		while(!Busy_Line){};
		make_voice(hundred);
		while(!Busy_Line);
		make_voice(11);//"��"
		if(ten>0)
		{
			while(!Busy_Line){};			
			make_voice(ten);
			while(!Busy_Line);			
			make_voice(12);//"ʮ"
			if(bit > 0)
			{
				while(!Busy_Line){};			
				make_voice(bit);
			}
		}
		else if((ten==0)&&(bit!=0))
		{
			while(!Busy_Line){};			
			make_voice(10);	
			while(!Busy_Line){};			
			make_voice(bit);
		}


	}

}

void make_voice(u8 temp)
{
	int i;
		One_Line_Low; 						 
		delay_ms(4);
	for(i=0;i<8;i++)
	{
		if((temp&0x01)==0)
		{			
			One_Line_0();
			temp = temp>>1;				
		} 
		else
		{			
			One_Line_1();
			temp = temp>>1;				
		}
	}
	One_Line_High; 
	delay_ms(400);
//	while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)){};
// GPIO_SetBits(GPIOB,GPIO_Pin_13);
	
}








