#ifndef _RED_H_
#define _RED_H_

uint32_t SysCtlClockGet(void);
void timer2_init (void);
void irmp_get_key(void);




#endif
